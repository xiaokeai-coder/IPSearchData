package com.tledu.tt.dao.impl;


import org.mybatis.spring.support.SqlSessionDaoSupport;

import com.tledu.tt.dao.IIPAndLocationDao;



public class IPAndLocationDao extends SqlSessionDaoSupport implements IIPAndLocationDao{

	@Override
	public String load(String aip) {

		return getSqlSession().getMapper(IPAndLocationDao.class).load(aip);
	}
	}

	






