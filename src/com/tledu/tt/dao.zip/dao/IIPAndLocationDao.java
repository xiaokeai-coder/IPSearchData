package com.tledu.tt.dao;



public interface  IIPAndLocationDao {

	public String load(String aip);
	
}
